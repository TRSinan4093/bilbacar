chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: "https://seyid.infy.uk/" });
});

chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: function () {
      (function () {
        const _0xabc1 = [
          "div",
          "Senan tərəfindən kodlanmışdır",
          "fixed",
          "50%",
          "translate(-50%, -50%)",
          "20px 40px",
          "#27ae60",
          "white",
          "40px",
          "bold",
          "10px",
          "9999",
          "center",
          "0px 0px 15px rgba(0, 0, 0, 0.5)",
          "appendChild",
          "display",
          "none",
          "log",
          "querySelectorAll",
          "name",
          "click",
          "textContent",
          "İrəli",
          "Hamısı cavablandı!",
        ];
        const messageDiv = document.createElement(_0xabc1[0]);
        messageDiv.textContent = _0xabc1[1];
        messageDiv.style.position = _0xabc1[2];
        messageDiv.style.top = _0xabc1[3];
        messageDiv.style.left = _0xabc1[3];
        messageDiv.style.transform = _0xabc1[4];
        messageDiv.style.padding = _0xabc1[5];
        messageDiv.style.backgroundColor = _0xabc1[6];
        messageDiv.style.color = _0xabc1[7];
        messageDiv.style.fontSize = _0xabc1[8];
        messageDiv.style.fontWeight = _0xabc1[9];
        messageDiv.style.borderRadius = _0xabc1[10];
        messageDiv.style.zIndex = _0xabc1[11];
        messageDiv.style.textAlign = _0xabc1[12];
        messageDiv.style.boxShadow = _0xabc1[13];
        document.body[_0xabc1[14]](messageDiv);

        setTimeout(() => {
          messageDiv.style[_0xabc1[15]] = _0xabc1[16];
        }, 5000);

        console[_0xabc1[17]]("60 Sualı cavablandırmağa başlayıram!");
        const totalQuestions = 59;
        let currentQuestion = 1;

        function answerAndNext() {
          console[_0xabc1[17]](`Cavablanır: ${currentQuestion} / ${totalQuestions}`);
          const radioButtons = document[_0xabc1[18]]('input[type="radio"]');
          const groupedQuestions = {};

          radioButtons.forEach((radio) => {
            const name = radio.getAttribute(_0xabc1[19]);
            if (!groupedQuestions[name]) groupedQuestions[name] = [];
            groupedQuestions[name].push(radio);
          });

          Object.values(groupedQuestions).forEach((group) => {
            const randomChoice = group[Math.floor(Math.random() * group.length)];
            randomChoice[_0xabc1[20]]();
          });

          const nextButton = [...document.querySelectorAll("span.button__label")].find((btn) =>
            btn[_0xabc1[21]].includes(_0xabc1[22])
          );

          if (nextButton) {
            nextButton[_0xabc1[20]]();
            console[_0xabc1[17]](`Növbəti sual: ${currentQuestion + 1}`);
          } else {
            console[_0xabc1[17]]("İrəli düyməsi tapılmadı!");
          }

          if (currentQuestion < totalQuestions) {
            currentQuestion++;
            setTimeout(answerAndNext, 2000);
          } else {
            console[_0xabc1[17]](_0xabc1[23]);
          }
        }

        answerAndNext();
      })();
    },
  });
});
